﻿

namespace default_mvc_template.Models
{

  public class DafaultClass
  {
    public string? id { get; set; }
    public string? description { get; set; }
  }

}
