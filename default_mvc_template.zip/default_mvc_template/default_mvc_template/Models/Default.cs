﻿

namespace default_mvc_template.Models
{

  public class DefaultObjectClass
  {
    public string? id { get; set; }
    public string? description { get; set; }
  }

}
