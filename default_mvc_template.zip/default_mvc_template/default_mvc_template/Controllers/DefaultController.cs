﻿using default_mvc_template.Models;

using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Web;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore;
using System.Configuration;
using System.Text.Json;



namespace default_mvc_template.Controllers
{
  public class DefaultController : Controller
  {

    public Dictionary<string, string> output_items_dictionary = new Dictionary<string, string>();
    public string json_outputparam = string.Empty;



    [HttpPost]
    [HttpGet]
    [Route("{controller}/{action}/{the_id}")]
    public JsonResult GetSomethingAndReturnSomething(string the_id) // to call this http://localhost:5144/default_mvc_template/GetSomethingAndReturnSomething
    {
      try
      {
        // put some code here to do some processing
        // such as reading values from SQL

        // put some code here to do some processing
        // such as reading values from SQL

        // put some code here to do some processing
        // such as reading values from SQL

        // put some code here to do some processing
        // such as reading values from SQL


        // return JSON to the calling program
        // using a dictionary object so I do not have to define a custom public class
        // every time I want to return disparate values
        output_items_dictionary.Clear();
        output_items_dictionary.Add("return_item1", "some value");
        output_items_dictionary.Add("return_item2", "some other value");
        output_items_dictionary.Add("Id", the_id);
        json_outputparam = JsonSerializer.Serialize(output_items_dictionary);


        // return JSON to the calling program
        // could also do this with the DefaultObjectClass custom public class as defined in Default.cs Model
        DefaultObjectClass obj_default = new();
        obj_default.id = the_id;
        json_outputparam = JsonSerializer.Serialize(obj_default);

        // return JSON to the calling program
        return Json(json_outputparam);
      }
      catch (Exception ex)
      {
        string result = ex.Message;
        return Json(result);
      }
    }




    public IActionResult Index()
    {
      return View();
    }
  }

}
