﻿using default_mvc_template.Models;

using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Web;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore;
using System.Configuration;




namespace default_mvc_template.Controllers
{
  public class DefaultController : Controller
  {

    public JsonResult Default(string Id) // to call this http://localhost:5144/Default/Default
    {
      try
      {
        DafaultClass obj_default = new();
        obj_default.id = "sadgsdfgsdfgfgsdf";

        return Json(obj_default.id);
      }
      catch (Exception ex)
      {
        string result = ex.Message;
        return Json(result);
      }
    }




    public IActionResult Index()
    {
      return View();
    }
  }

}
