
using System.Web.Mvc;
using System.Security;
using System.Text;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http.Headers;



namespace default_mvc_template.Program
{
  public class Program
  {

    public static void Main(string[] args) // because I prefer this method
    {
      try
      {
        var builder = WebApplication.CreateBuilder(args);
        builder.Services.AddControllersWithViews();

        var startup = new Startup(builder.Configuration); // startup.cs
        startup.ConfigureServices(builder.Services); // for ConfigureServices // startup.cs

        var app = builder.Build();
        app.UseRouting();
        app.UseEndpoints(x => x.MapControllers());
        app.UseStaticFiles();

        app.Use(async (context, next) =>
        {
          context.Response.Headers.Add("Content-Security-Policy", "default-src 'self'");
          context.Response.Headers.Add("X-Frame-Options", "DENY");
          context.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
          context.Response.Headers.Add("Referrer-Policy", "no-referrer");
          context.Response.Headers.Add("X-Permitted-Cross-Domain-Policies", "none");
          await next();
        });


        app.MapControllerRoute
        (
          name: "GetSomethingAndReturnSomething",
          pattern: "{controller}/{action}/{the_id}",
          defaults: new { controller = "Default", action = "GetSomethingAndReturnSomething ", the_id = UrlParameter.Optional }
        );


        app.MapControllerRoute // the default view - index.chtml
        (
          name: "WallsDefault",
          pattern: "{controller=Default}/{action=Index}/{id?}" // the index page
        );

        app.Run();
      }
      catch (Exception ex)
      {
        throw new Exception(ex.Message.ToString());
      }
    }

  }
}

